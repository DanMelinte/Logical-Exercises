﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.1: Să se citească de la tastatură două variabile de tip double (se citește cu %lf, nu cu %g!!!) și
să se afișeze numele variabilei care se află la adresa cea mai mică de memorie utilizând pointeri.
*/

int main() // variabila declarata prima adica in cazul de fata "a" va avea mereu o adresa mai mica 
{
	double  a, b;
	double* x, * y;

	x = &a;
	y = &b;	

	printf("Introduceti a : "); scanf("%lf", &a);
	printf("Introduceti b : "); scanf("%lf", &b);

	printf("\n\n");
	if (x > y)
	{
		printf("adresa a %p > adresa b %p", x, y);
		printf("\n%lf", *x);
	}
	else
	{
		printf("adresa b %p > adresa a %p", y, x);
		printf("\n%lf", *y);
	}
}