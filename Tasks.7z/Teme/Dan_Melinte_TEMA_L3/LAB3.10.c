﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.10: Să se implementeze, fără a se folosi variabile index, un program cu următorul meniu:
1. Citire -citește o valoare reală și o adaugă într-un vector cu maxim 100 de elemente
2.Afișare -afișează toate valorile din vector
3.Ștergere -citește o valoare și șterge toate elementele egale cu valoarea citită
4. Ieșire
*/

int main()
{
	float V[100];
	int i, j;
	int n = 0;
	float sterg;
	int opt;

	while (1)
	{
		system("cls");
		printf(
			"1. Citire\n"
			"2. Afisare\n"
			"3. Stergere\n"
			"4. Iesire\n"
		);

		printf("\nIntrodu Optiunea : ");
		while (scanf("%i", &opt) == 0 && getchar() != '\n');

		switch (opt)
		{
		case 1:
			printf("Introduceti valoarea V[%i] : ", n);
			scanf("%f", (V + n));
			n++;
			_getch(); break;

		case 2: 
			printf("\n");
			for (i = 0; i < n; i++)
				printf("%f ", *(V + i));			
			_getch(); break;

		case 3: 
			printf("Introduceti valoare ce doriti sa o stergeti : ");
			scanf("%f", &sterg);
			for (i = 0; i < n; i++)
			{
				if (*(V + i) == sterg)
				{
					for (j = i; j < n; j++)
					{
						*(V + j) = *(V + j + 1);
					}
					n--;
					i--;
				}
			}
			_getch(); break;
		case 4: 
			exit(1);
			_getch(); break;
		default:
			printf("\nReintroduceti : ");
			break;
		}
	}
	return 0;
}