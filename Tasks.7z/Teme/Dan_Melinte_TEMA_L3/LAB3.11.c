﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.11: Să se implementeze, fără a se folosi indecși, următorul program: 
se citește pe rând câte o valoare întreagă și se inserează într-un vector, 
astfel încât vectorul să fie mereu sortat crescător. 
După fiecare inserare se va afișa noul vector. 
Programul se termină la citirea valorii 0. 
Presupunem că vectorul va avea maxim 100 de elemente
*/

int main()
{
	int V[105];
	int i, j;
	int n = -1;
	int ok;
	int aux;

	do
	{
		n++;
		printf("Introduceti V[%i] : ", n); scanf("%i", V + n);
		if (*(V + n) == 0) break;

		do
		{
			ok = 1;
			for (i = 0; i < n; i++)
			{
				if (*(V + i) > *(V + i + 1))
				{
					aux = *(V + i);
					*(V + i) = *(V + i + 1);
					*(V + i + 1) = aux;
					ok = 0;
				}
			}
		} while (!ok);

		for (i = 0; i <= n; i++)
		{
			printf("%i ", *(V + i));
		}
		printf("\n");

	} while (n < 100);

	return 0;
}