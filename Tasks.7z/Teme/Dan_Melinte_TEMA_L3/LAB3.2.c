﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.2: Se citesc două variabile, a și b, de tip întreg. 
Să se stocheze într-un pointer adresa variabilei care
conține valoarea maximă și apoi să se afișeze valoarea pointată.
*/

int main()
{
	int a, b;
	int* c;

	printf("Introduceti a : "); scanf("%i", &a);
	printf("Introduceti b : "); scanf("%i", &b);

	if (a > b)
		c = &a;
	else c = &b;

	printf("%i", *c);
}