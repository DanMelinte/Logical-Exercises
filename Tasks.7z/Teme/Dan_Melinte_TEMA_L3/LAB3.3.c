﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.3: Scrieți un program care interschimbă valorile a două variabile de tip întreg utilizând pointeri.
*/

void interschimba(int *a, int *b)
{
	int aux;

	aux = *a;
	*a = *b;
	*b = aux;
}

int main()
{
	int a, b;

	printf("Introduceti a : "); scanf("%i", &a);
	printf("Introduceti b : "); scanf("%i", &b);

	printf("\na = %i", a);
	printf("\nb = %i", b);

	interschimba(&a, &b); 	printf("\n------------------");

	printf("\na = %i", a);
	printf("\nb = %i", b);
}