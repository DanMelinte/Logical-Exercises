﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.4: Să se afișeze câte elemente negative sunt în vectorul {7, -5, 4, 3, -9, 2, -8} 
utilizând pointeri, fără indecși. (Fără indecși înseamnă că în cod nu va exista niciun v[i])
*/

int main()
{
	int V[] = { 7, -5, 4, 3, -9, 2, -8 };
	int* a;
	int i;
	int ok = 0;

	// Varianta 2.
	for (a = &V; a < V + 7; a++)
	{
		printf("%i ", *a);
		if (*a < 0)
			ok++;
	}

	// Varianta 1.
	//for (i = 0; i < 7; i++)
	//{
	//	printf("%i ", *(a + i));
	//	if (*(a + i) < 0)
	//		ok++;
	//}

	printf("\n%i elemente negative\n", ok);
}