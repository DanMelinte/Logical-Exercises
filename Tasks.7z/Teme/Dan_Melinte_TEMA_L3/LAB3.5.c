﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.5: Să se afișeze minimul elementelor din vectorul 
{7, -5, 4, 3, -9, 2, -8} utilizând pointeri, fără indecși.
*/

int main()
{
	int V[] = { 7, -5, 4, 3, -9, 2, -8 };
	int* a;
	int i;
	int min = *V;

	//Varianta 1.
	for (a = &V; a < V + 7; a++)
	{
		if (min > *a)
		{
			min = *a;
		}
	}

	// Varianta 2.
	//for (i = 0; i < 6; i++)
	//{
	//	if (min > *(a + i + 1))
	//	{
	//		min = *(a + i + 1);
	//	}
	//}

	printf("%i", min);
}