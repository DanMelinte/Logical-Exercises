﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.6: Se citește un număr n (n<=10) și apoi n numere întregi. 
Se cere să se sorteze aceste numere în ordine descrescătoare utilizând 
pointeri, fără indecși. (Inclusiv citirea se va face cu pointeri.)
*/

int main()
{
	int n;
	int V[10];
	int i;
	int ok, aux;

	printf("Introduceti n : ");
	do
	{
		scanf("%i", &n);
	} while (n > 10);

	for (i = 0; i < n; i++)
	{
		printf("V[%i] : ", i);
		scanf("%i", (V + i));
	}

	do
	{
		ok = 1;
		for (i = 0; i < n - 1; i++)
		{
			if (*(V + i) > *(V + i + 1))
			{
				aux = *(V + i);
				*(V + i) = *(V + i + 1);
				*(V + i + 1) = aux;
				ok = 0;
			}
		}
	} while (!ok);

	for (i = 0; i < n; i++)
		printf("%i ", *(V + i));
}