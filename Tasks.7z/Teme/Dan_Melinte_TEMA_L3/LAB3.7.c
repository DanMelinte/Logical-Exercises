﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.7: Să se șteargă din vectorul{ 5, 8, 1, 4, 2, 6, 9 } toate elementele pare, 
păstrând neschimbată ordinea elementelor, după care să se afișeze noul vector.
Utilizați pointeri, fără indecși.
*/

int main()
{
	int V[] = { 5, 8, 1, 4, 2, 6, 9 };
	int i,j;
	int n = 7;

	for (i = 0; i < n; i++)
		printf("%i ", *(V + i));

	for (i = 0; i < n; i++)
	{
		if (*(V + i) % 2 == 0)
		{
			for (j = i; j < n; j++)
			{
				*(V + j) = *(V + j + 1);
			}
			i--;
			n--;
		}
	}

	printf("\n");

	for (i = 0; i < n; i++)
		printf("%i ", *(V + i));

	return 0;
}