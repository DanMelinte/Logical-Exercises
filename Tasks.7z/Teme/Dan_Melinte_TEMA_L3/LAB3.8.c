﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.8: Se dă vectorul {7, -5, 4, 3, -9, 2, -8}. 
Să se insereze înainte de fiecare valoare din vectorul original
negativul ei. Utilizați pointeri, fără indecși.
*/

int main() //Negativul ei sau Opusul ? => am facut pentru ambele cazuri
{
	int V[14] = { 7, -5, 4, 3, -9, 2, -8 }; // deoarece avem 7 elemente si daca pentru toate 
											// trebuie sa inseram opusul pai se dubleaza spatiul
	int i, j;
	int n = 7;

	for (i = 0; i < n; i++)
		printf("%i ", *(V + i));

	// Varianta 1. inserez in fata fiecarui element opusul lui
	for (i = 0; i < n; i+=2)
	{
		for (j = n; j > i; j--)
		{
			*(V + j) = *(V + j - 1);
		}
		n++;
		*(V + i) = -*(V + i + 1);
	}

	// Varianta 2. Inserez in fata fiecarui element POZITIV negativul lui
	/*
	for (i = 0; i < n; i += 2)
	{
		if (*(V + i) > 0)
		{
			for (j = n; j > i; j--)
			{
				*(V + j) = *(V + j - 1);
			}
			n++;
			*(V + i) = -*(V + i + 1);
		}
		else i--;
	}
	*/

	printf("\n");

	for (i = 0; i < n; i++)
		printf("%i ", *(V + i));

	return 0;
}