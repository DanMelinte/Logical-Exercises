﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 3.9: Se citesc n<=10 valori întregi. 
Folosind doar pointeri, fără niciun fel de indexare, să se afișeze
toate valorile care au cel puțin un duplicat. 
(Inclusiv citirea se va face cu pointeri.)
*/

int main()
{
	int V[10]; // vectorul initial
	int OK[5]; //vectorul cu elemente cu cel putin un dublicat
	int i, j, k, l;
	int n;
	int ok;
	int okk;

	do
	{
		printf("Introduceti n : ");
		scanf("%i", &n);
	} while (n > 10);

	for (i = 0; i < n; i++)
	{
		printf("V[%i] : ", i);
		scanf("%i", (V + i));
	}

	printf("\n");

	for (i = 0, k = 0; i < n; i++)
	{
		ok = *(V + i);
		for (j = i + 1; j < n; j++)
		{
			if (ok == *(V + j))
			{
				okk = 0;
				for (l = 0; l < k; l++)
				{
					if (*(OK + l) == ok)
						okk++;
				}
				if (okk == 0)
				{
					*(OK + k) = ok;
					k++;
				}
			}
		}
	}

	for (i = 0; i < k; i++)
	{
		printf("%i ", *(OK + i));
	}

	return 0;
}