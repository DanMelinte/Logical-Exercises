#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

// 1. Scrieti o functie care intoarce numarul de caractere dintr-un sir sir2

int StrLenghts()
{
	char sir2[] = "Sirul Meu este al meu"; //21
	int n = 0;

	while (*(sir2+n) != '\0')
		n++;

	return n;
}

int main()
{
	printf("%i", StrLenghts());
	return 0;
}