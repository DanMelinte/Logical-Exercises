#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

// P2.Scrieti o functie care intoarce numarul de caractere c dintr - un sir sir3
// (*sir3 si c se transmit ca parametri)

int StrLenghts(char* sir2, int *c)
{
	*c = 0;
	while (*(sir2 + *(c)) != '\0')
		(*c)++;

	return *c;
}

int main()
{
	char sir2[] = "Sirul Meu este al meu"; //21
	int c; 

	printf("%i", StrLenghts(&sir2, &c));

	return 0;
}