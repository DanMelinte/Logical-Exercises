#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
P3. Scrieti o functie care compara doua siruri de caractere sir1 cu sir
*/

void Compara(char* sir1, char* sir2) //compara sirurile dupa numarul de caractere si precum strcmp
{
	int n1, n2;
	int i;

	n1 = n2 = 0;

	while (*(sir1 + n1) != '\0')
		n1++;
	while (*(sir2 + n2) != '\0')
		n2++;
	//Dupa numarul de caractere
	if (n1 == n2)
		printf("Sirurile sunt egale dupa numarul de caractere");
	else if(n1 > n2)
		printf("Sirul 1 este mai mare ca sirul 2 dupa numarul de caractere");
	else if(n2 > n1)
		printf("Sirul 2 este mai mare ca sirul 1 dupa numarul de caractere");

	printf("\n"); 

	for (i = 0; i < n1; i++) // strcmp
	{
		if ((int)*(sir1 + i) > (int)*(sir2 + i))
		{
			printf("Sirul 1 este mai mare ca sirul 2 dupa alfabet");
			break;
		}
		if ((int)*(sir1 + i) < (int)*(sir2 + i))
		{
			printf("Sirul 2 este mai mare ca sirul 1 dupa alfabet");
			break;
		}
	}
}

int main()
{
	char sir1[] = "Sirul Meu este al meu"; //21
	char sir2[] = "Sirul Meu nu este al meu"; //28

	Compara(&sir1, &sir2);

	return 0;
}