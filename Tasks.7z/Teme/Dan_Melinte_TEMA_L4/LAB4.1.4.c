#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
P4. Scrieti o functie care permite cautarea unui subsir sub intr-un sir s
*/

void Cauta(char* sir1, char* sir2) // analog la strstr deasemenea returnez si prima pozitie in care sa depistat sirul 
{
	int n1, n2;
	int i,j;
	int ok = 0;
	n1 = n2 = 0;

	char a, b;

	while (*(sir1 + n1) != '\0')
		n1++;
	while (*(sir2 + n2) != '\0')
		n2++;

	if (n1 <= n2)
	{
		for (i = 0; i < n2; i++)
		{
			if (*(sir1 + ok) == *(sir2 + i))
			{
				ok++;
				if (ok == n1)
					printf("Sirul 1 se contine in sirul 2 pe pozitia : %i", i-1);
			}
			else ok = 0;
		}
	}
	else
		printf("Nu se include");
}

int main()
{
	char sir1[] = "BB";
	char sir2[] = "aaa BBB ccc";

	Cauta(&sir1, &sir2);

	return 0;
}