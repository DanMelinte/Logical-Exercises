#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

/*
P5. Sa se citeasca de la tastatura 2 texte, retinute in sirurile t1 si t2. Sa se determine
vocala(vocalele) care apare(apar) de cele mai multe ori in cele 2 texte.
*/	

void NrVocale(char* t1, char* t2)
{
	char Voc[5] = { 'a', 'o', 'e', 'i', 'u' };
	int NVoc[6] = { 0 };
	int i, j;

	int ok = 0;
	int index = 0;
	int aux = 0;

	for (i = 0; i < strlen(t1) || i < strlen(t2); i++)
	{
		for (j = 0; j < 5; j++)
		{
			if (*(t1 + i) == *(Voc + j))
			{
				NVoc[j] ++;
				ok++;
			}
			if (*(t2 + i) == *(Voc + j))
			{
				NVoc[j]++; 
				ok++;
			}
		}
	}

	if (ok != 0)
	{

		do
		{
			ok = 1;

			for (i = 0; i < 5; i++)
			{
				if (NVoc[index] <= NVoc[i] && NVoc[i] != 0)
				{
					if (NVoc[i] == aux || aux == 0)
					{
						index = i;
						ok = 0;
					}
				}
			}

			if (NVoc[index] != 0)
			{
				aux = NVoc[index];
				printf("Vocala - %c apare de %i ori\n", Voc[index], NVoc[index]);
				NVoc[index] = 0;
			}

		} while (!ok);
	}
	else printf("In propozitii nu sunt vocale");
	
}

int main()
{
	char t1[20];
	char t2[20];

	printf("Introduceti textul 1 : "); scanf("%s", t1);
	printf("Introduceti textul 2 : "); scanf("%s", t2);

	NrVocale(t1, t2);

	return 0;
}