#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

/*
P6. Se citeste de la tastatura un text scris pe mai multe randuri, cuvintele fiind despartite
prin unul din caracterele � ,.;!�.
Sa se extraga cuvintele din text si apoi sa se afiseze alfabetic. Daca un cuvant apare de mai
multe ori, el va fi scris o singura data.
*/

void ExtragCuvintele(int n, int* k, char* Rand, char Word[][20]) // Analog la functia strtok
{
	int i, j;
	int ok;
 
	printf("Introduceti Textul : \n");
	getchar();

	for (i = 0; i < n; i++)
	{
		gets(Rand);

		for (j = 0, ok = 0; j < strlen(Rand); j++)
		{
			if (Rand[j] != ' ' && Rand[j] != '.' && Rand[j] != ';' && Rand[j] != '!' && Rand[j] != '"')
			{
				Word[*k][ok] = Rand[j];
				ok++;
			}
			else if (ok != 0)
			{
				Word[*k][ok] = '\0';
				ok = 0;
				(*k)++;
			}
		}

		Word[*k][ok] = '\0';
		ok = 0;
		if (Word[*k][ok] != '\0')
			(*k)++;
	}
}

int main()
{
	int n; // numarul de randuri
	char Rand[100];
	int i;
	int k = 0; //numarul de cuvinte
	int ok;

	char Word[50][20];
	char aux[20];

	printf("Cate randuri doriti sa aiba textul : ");
	scanf("%i", &n);

	ExtragCuvintele(n, &k, Rand, Word); //Extrag cuvintele din fiecare Rand introdus si le stokez in variabila Word

	do // Sortez alfabetic cuvintele stocate in variabila Word
	{
		ok = 1;
		for (i = 0; i < k - 1; i++)
			if ((strcmp(Word[i], Word[i + 1]) > 0))
			{
				strcpy(aux, Word[i]);
				strcpy(Word[i], Word[i + 1]);
				strcpy(Word[i + 1], aux);
				ok = 0;
			}
	} while (!ok);

	for (i = 0; i < k; i++)
		if (strcmp(Word[i], Word[i + 1]) != 0)
			printf("%s ", Word[i]);

	return 0;
}