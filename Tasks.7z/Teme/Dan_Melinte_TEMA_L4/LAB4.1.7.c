#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
/*
P7. Se citeste de la tastatura un text de maxim 250 caractere. Sa se separe constantele
zecimale intregi si sa se calculeze suma acestora(fiecare constanta va avea lungimea pana la
20 de cifre zecimale).
*/

void ExtragConstantele(int** Constanta, char Text[], int* k, int* ok)
{
	int i, j;

	for (j = 0, ok[*k] = 0; j < strlen(Text); j++)
	{
		if (Text[j] >= '0' && Text[j] <= '9')
		{
			Constanta[*k][ok[*k]] = Text[j] - 48;
			ok[*k]++;
		}
		else if (ok[*k] != 0 || ok[*k] > 20)
		{
			(*k)++;
			ok[*k] = 0;
		}
	}
}

int main()
{
	char Text[250];
	int ok[20];
	int k = 0;
	int aux[20] = { 0 };
	int i,j;

	int **Constanta;

	printf("Introduceti Textul : \n");
	getchar();
	gets(Text);

	Constanta = (int**)malloc(strlen(Text) * sizeof(int)); //Nu pot fi mai multe constante decat caractere in text 
	for (i = 0; i < strlen(Text); i++)						//Deci aloc minimul necesar
		Constanta[i] = (int*)malloc(20 * sizeof(int));

	ExtragConstantele(Constanta, Text, &k, &ok);

	printf("Cifrele Extrase : ");
	for (i = 0; i <= k; i++)
	{
		for (j = 0; j < ok[i]; j++)
		{
			printf("%i", Constanta[i][j]);
		}
		printf("; ");
	}

	printf("\n");

	for (i = 0; i <= k; i++)
	{
		for (j = 0; j < ok[i]; j++)
		{
			aux[i] += (pow(10, ok[i] - j -1 ) * Constanta[i][j]);
		}
		printf("%i + ", aux[i]);
		aux[k+1] += aux[i];
	}

	printf("= %i ", aux[k+1]);

	return 0;
}