#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
/*
P8. Sa se citeasca de la tastatura un text incheiat cu caracterul �.�. Scrieti un program care
plaseaza caracterele din textul citit intr-o matrice patratica, caracter cu caracter, in ordine
pe linii "(coloane?)" de sus in jos si pe fiecare linie de la stanga la dreapta. Daca nu sunt suficiente
caractere se completeaza matricea cu spatii. Afisati matricea obtinuta.
*/

int main()
{
	char Text[250];
	char Mat[30][30];
	int i = -1, j, k;
	int n = 0;
	int ns = 0; // numarul de spatii

	do
	{
		system("cls");
		printf("Introduceti Textul (trebuie sa se termine cu '.') : \n");
		i++;
		gets(Text);
	} while (Text[strlen(Text) - 1] != '.');

	for (i = 0; i < sqrt(strlen(Text)); i++)
	{
		for (j = 0; j < sqrt(strlen(Text)); j++, n++)
		{
			if (Text[n] != ' ')
			{
				if (n <= strlen(Text))
					Mat[i][j] = Text[n];
				else if (n >= strlen(Text))
					Mat[i][j] = ' ';
			}
			else
			{
				for (k = 0; Text[n] == ' '; k++)
				{
					n++;
					ns++;
				}
				Mat[i][j] = Text[n];
			}
		}
	}

	for (i = 0; i < sqrt(strlen(Text) - ns); i++)
	{
		for (j = 0; j < sqrt(strlen(Text) - ns); j++)
		{
			printf("%3c", Mat[i][j]);
		}
		printf("\n");
	}

	return 0;
}