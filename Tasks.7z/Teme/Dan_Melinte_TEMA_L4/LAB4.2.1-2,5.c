#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

/*Structuri 
P1. Sa se creeze o baza de date cu produse definite prin nume si pret. Operatiile necesare
sunt introducere si afisare si ele se vor da pe rand de la tastatura, utilizatorului fiindu-i
prezentat un meniu de unde poate alege operatia dorita.

P2. 
	A)Realizati apoi operatia de cautare de produs dupa nume. Acesta va fi introdus
de la tastatura. Daca s-a gasit produsul, se va afisa pretul sau. Daca nu s-a gasit, se va afisa
mesajul �Nu exista�.
	B)eliminati produsele gasite in cautarea dupa nume
	C)Ordonati produsele dupa pret, descrescator si afisati noua lista.

	P5. Sa se modifice P1 astfel incat la adaugarea unui produs, daca numele respectiv
exista deja in baza de date, acesta sa nu mai fie adaugat ci sa fie schimbat pretul vechi cu
cel nou introdus
*/

typedef struct
{
	char nume[20];
	int pret;
}BD;
void Insert(BD *Produs, int *n)
{
	int i;
	int ok = 0;
	char N[20];

	printf("Introduceti Produsul : \n");
	printf("Nume : "); scanf("%s", N);

	for (i = 1; i <= *n; i++)
	{
		if (!strcmp(N, (Produs + i)->nume))
		{
			printf(" - Deja existent\n");
			printf("Pret : "); scanf("%i", &(Produs + i)->pret);
			ok = 1;
		}
	}
	
	if (ok == 0)
	{
		(*n)++;
		strcpy((Produs + *n)->nume, N);
		printf("Pret : "); scanf("%i", &(Produs + *n)->pret);
	}
}
void Afisare(BD* Produs, int n)
{
	int i;

	for (i = 1; i <= n; i++)
	{
		printf("%5s", (Produs + i)->nume);
		printf("%5i", (Produs + i)->pret);
		printf("\n");
	}
}
void Cautare(BD* Produs, int *n)
{
	int i,j;
	char Name[20];
	int ok = 0;

	printf("Introduceti numele cautat : ");
	scanf("%s", Name);

	for (i = 1; i <= *n; i++)
	{
		if ((strcmp(Name, (Produs + i)->nume) == 0))
		{
			printf("%5i", (Produs + i)->pret);
			printf("\n");
			ok++;

			for (j = i; j < *n; j++)
			{
				*(Produs + j) = *(Produs + j + 1);
			}
			(*n)--;
			i--;
		}
	}

	if (ok == 0)
		printf("Nu exista");
}
void Ordoneaza(BD* Produs, int* n)
{
	int i, j;
	int ok;
	BD aux;

	do
	{
		ok = 1;
		
		for (i = 1; i <= *n-1; i++)
		{
			if (Produs[i].pret < Produs[i + 1].pret)
			{
				aux = Produs[i];
				Produs[i] = Produs[i + 1];
				Produs[i + 1] = aux;

				ok = 0;
			}
		}

	} while (!ok);

	Afisare(Produs, *n);

}

int main()
{
	BD Produs[25];
	int n = 0;
	int opt;
	int i;

	while (1)
	{
		system("cls");
		printf(
			"0. Esire\n"
			"1. Introducere Produs\n"
			"2. Afisare\n"
			"3. Cautare dupa nume\n"
			"4. Ordoneaza dupa pret descrescator\n\n"
			"Introduceti Optiunea : "
		);

		while ((scanf("%i", &opt)) != 0 && getchar() != '\n');

		switch (opt)
		{
		case 0: exit(1);
		case 1: Insert(Produs, &n); _getch(); break;
		case 2: Afisare(Produs, n); _getch(); break;
		case 3: Cautare(Produs, &n); _getch(); break;
		case 4: Ordoneaza(Produs, &n); _getch(); break;
		default:
			break;
		}
	}

	return 0;
}