#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

/*Structuri 
	P 3: Se defineste o structura �Drept� care contine latimea l si inaltimea h a
dreptunghiului. Se cere nr<=5 si apoi cele nr dreptunghiuri. Sa se afiseze informatii despre
componentele dreptunghiului de arie maxima.
*/

typedef struct
{
	int l, h;
}Drept;

int main()
{
	Drept d[5];
	int max[5] = { 0 };
	int imax = 0;
	int n;
	int i;

	printf("Cate dreptunghiuri doriti sa introduceti : "); //LAB 2.P3
	while(scanf("%i", &n) > 5);

	for (i = 0; i < n; i++)
	{
		printf("Introduceti Triunghiul [%i] : \n", i);
		printf("lungimea : "); scanf("%i", &d[i].l);
		printf("inaltimea : "); scanf("%i", &d[i].h);
		max[i] = d[i].h * d[i].l;
	}

	for (i = 0; i < n - 1; i++)
	{
		if ( max[0] < max[i+1])
		{
			max[0] = max[i + 1];
			imax = i + 1;
		}
	}
	printf("Dreptunghiul cu aria maxima = %i unitati patratice (%i,%i)", max[0], d[imax].l, d[imax].h);

	return 0;
}