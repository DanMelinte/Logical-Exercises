#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

/*Structuri
P4: Se defineste o structura �Punct� cu membrii �a� si �b�numere reale.
Se cere o valoare v<=10 si apoi v puncte. Sa se calculeze distanta dintre cele mai
apropiate doua puncte si sa se afiseze.
Se va folosi din <math.h> functia �sqrt� (square root), pentru extragerea radicalului.
*/

typedef struct
{
	float a, b;
}Punct;

int main()
{
	Punct v[10];
	int n;
	int i, j;

	float dist[40] = { 0 };
	float distMin = { 0 };
	int k;
	int o;
	int Ind1 = 0;
	int Ind2 = 1;

	printf("Introduceti numarul de puncte : ");
	do
	{
		scanf("%i", &n);
	} while (n > 10);

	for (i = 0; i < n; i++)
	{
		printf("Punctul[%i] : \n", i);
		printf("a = "); scanf("%fl", &v[i].a);
		printf("b = "); scanf("%fl", &v[i].b);
		distMin *= v[i].a * v[i].b;
	}

	for (i = 0, k = 0, o = 0; i < n; i++)
	{
		for (j = i + 1; j < n; j++, k++)
		{
			dist[k] = sqrt(pow((v[i].a - v[j].a), 2) + pow((v[i].b - v[j].b), 2));
			printf("\nDistanta P[%i] - P[%i] = %f", i, j, dist[k]);

			if (distMin >= dist[k])
			{
				distMin = dist[k];

				Ind1 = i;
				Ind2 = j;
			}
		}
	}
	printf("\n\nDistanta minima %f intre Punctele %i - %i", distMin, Ind1, Ind2);

	return 0;
}