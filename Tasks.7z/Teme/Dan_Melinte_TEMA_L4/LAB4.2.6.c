#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

/*Structuri
P6. O structura contine ora (intreg) la care s-a masurat o anumita temperatura si
valoarea acestei temperatori (real). Se cere n<=10 si apoi n temperaturi. Se cere apoi o ora
de inceput si una de sfarsit. Sa se afiseze media temperaturilor care au fost masurate in acel
interval orar, inclusiv in capetele acestuia
*/

typedef struct
{
	int ora;
	float temp;
}Med;

int main() // Nu am pus interval necesar pentru temperatura intrucat nu este specificat ce temperatura masuram
{
	Med M[10];
	int n;
	int i;

	int OraI, OraF;

	float MedTemp = 0;
	int Nr = 0;

	printf("Introduceti numarul de ore : ");
	do
	{
		scanf("%i", &n);
	} while (n > 10);

	printf("Introduceti intervalul de ore dorit : \n");
	do
	{
		printf("Ora Start : "); scanf("%i", &OraI);
		printf("Ora Finish : "); scanf("%i", &OraF);
	} while (OraI < 0 || OraI > 23 || OraF < 0 || OraF > 23);

	for (i = 0; i < n; i++)
	{
		printf("Introduceti Datele[%i] : \n", i);
		do
		{
			printf("Ora : "); scanf("%i", &M[i].ora);
		} while (M[i].ora < 0 || M[i].ora > 23);
		printf("Temperatura : "); scanf("%fl", &M[i].temp);

		if (M[i].ora >= OraI && M[i].ora <= OraF)
		{
			MedTemp += M[i].temp;
			Nr++;
		}
	}

	printf("\n\nMedia temperaturilor cuprinse intre orele %i - %i = %g grade", OraI, OraF, MedTemp / Nr);

	return 0;
}