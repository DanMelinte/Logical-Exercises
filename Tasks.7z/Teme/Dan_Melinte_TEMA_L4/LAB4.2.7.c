#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

/*Structuri
P7. Sa se descompuna un numar in factori primi memorand rezultatul sub forma unui
vector de structuri. Fiecare element va cuprinde doua campuri:
a. unul care contine divizorul prim
b. unul care contine puterea la care apare acesta in descompunere
*/

typedef struct
{
	int Divizor;
	int Puterea;
}Prim;

int main()
{
	Prim P[20];
	int n = 0;

	int Numar;
	int i = 2;

	int k;

	printf("Introduceti Numarul pentru descompunere : ");
	do
	{
		scanf("%i", &Numar);
	} while (Numar <= 1); 

	for (i = 2; i <= Numar; i++) 
	{
		if (Numar % i == 0) 
		{
			printf("%d^", i); 
			
			P[n].Divizor = i; // Stocam Divizorul pe pozitia sa

			for (k = 0; Numar % i == 0; k++) //Numaram puterea (k)
				Numar /= i;

			if (i <= Numar)
				printf("%d * ", k);
			else printf("%d", k);

			P[n].Puterea = k; // Stocam puterea divizorului curent

			n++; // Trecem la elementul urmator
		}
	}
	
	printf("\n");

	for (i = 0; i < n; i++)
		printf("\nElement[%i] : %i ^ %i", i, P[i].Divizor, P[i].Puterea);

	return 0;
}