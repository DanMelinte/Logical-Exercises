﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

/*Structuri
P8 Se citesc datele despre elevii unei clase, respectiv numele şi data naşterii. Să se
ordoneze elevii în ordinea LEXICOGRAFICA după nume şi să se afişeze această situaţie.
*/

typedef struct
{
	int zi;
	int luna;
	int an;
}DataNasterii;

typedef struct
{
	char Nume[20];
	DataNasterii Data;
}Clasa;

int main()
{
	Clasa Elev[20];
	Clasa aux;
	int n;

	int i;
	int ok;

	printf("Introduceti numarul de elevi : ");
	scanf("%i", &n);

	for (i = 0; i < n; i++)
	{
		printf("Introduceti Elevul %i : \n",i);
		printf("Numele : "); scanf("%s", Elev[i].Nume);
		printf("Data Nasterii : "); scanf("%i.%i.%i", &Elev[i].Data.zi, &Elev[i].Data.luna, &Elev[i].Data.an);
	}

	for (i = 0; i < n; i++)
	{
		printf("\nElevul %i : ", i);
		printf("%8s ", Elev[i].Nume);
		printf("%i.", Elev[i].Data.zi);
		if(Elev[i].Data.luna < 10)
			printf("0%i.", Elev[i].Data.luna);
		printf("%i.", Elev[i].Data.luna);
		printf("%i", Elev[i].Data.an);
	}

	do
	{
		ok = 1;

		for (i = 0; i < n-1; i++)
		{
			if (strcmp(Elev[i].Nume, Elev[i + 1].Nume) > 0)
			{
				aux = Elev[i];
				Elev[i] = Elev[i+1];
				Elev[i+1] = aux;

				ok = 0;
			}
		}

	} while (!ok);

	printf("\nSortat\n");

	for (i = 0; i < n; i++)
	{
		printf("\nElevul %i : ", i);
		printf("%8s ", Elev[i].Nume);
		printf("%i.", Elev[i].Data.zi);
		if (Elev[i].Data.luna < 10)
			printf("0%i.", Elev[i].Data.luna);
		printf("%i.", Elev[i].Data.luna);
		printf("%i", Elev[i].Data.an);
	}

	return 0;
}