﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <malloc.h>
/*
P5.//Să se scrie un program care gestionează date despre un grup de studenţi.
Pentru fiecare student se memorează numele şi numărul matricol.
Programul trebuie să implementeze următoarele operaţii:
	- citirea numărului de studenţi şi a datelor acestora;
	- afişarea datelor tuturor studenţilor;
	- sortarea listei de studenţi în ordinea alfabetică a numelor;
	- sortarea listei de studenţi în ordinea crescătoare a numerelor matricole;
	- căutarea unui student pentru care se precizează numele şi afişarea poziţiei pe care o ocupă acesta în lista
	ordonată alfabetic după numele studenţilor;
	- căutarea unui student pentru care se precizează numărul matricol şi afişarea poziţiei pe care o ocupă
	acesta în lista ordonată crescător după numărul matricol al studenţilor;
*/

typedef struct
{
	char nume[20];
	int NrMat;
}Stud;

void SortName(Stud* Student,int n)
{
	int ok;
	int i;
	Stud aux;

	char opt[20];

	do
	{
		ok = 1;
		for (i = 0; i < n - 1; i++)
		{
			if ((strcmp(Student[i].nume, Student[i + 1].nume)) > 0)
			{
				aux = Student[i];
				Student[i] = Student[i + 1];
				Student[i + 1] = aux;

				ok = 0;
			}
		}
	} while (!ok);

	printf("\n\nSortat dupa nume : \n");
	for (i = 0; i < n; i++)
	{
		printf("%2i", i);
		printf("%10s\t", Student[i].nume);
		printf("%5i\n", Student[i].NrMat);
	}

	printf("Introduceti numele cautat in lista sortata dupa nume ^ : ");
	scanf("%s", opt);

	for (i = 0; i < n; i++)
	{
		if ((strcmp(Student[i].nume, opt)) == 0)
		{
			printf("Persoana cu acest nume se intalneste pe pozitia : ");
			printf("%i", i);
			break;
		}
	}

}

void SortNr(Stud* Student, int n)
{
	int ok;
	int i;
	Stud aux;
	int opt;

	do
	{
		ok = 1;
		for (i = 0; i < n - 1; i++)
		{
			if (Student[i].NrMat > Student[i + 1].NrMat)
			{
				aux = Student[i];
				Student[i] = Student[i + 1];
				Student[i + 1] = aux;

				ok = 0;
			}
		}
	} while (!ok);

	printf("\n\nSortat dupa nr matricol : \n");
	for (i = 0; i < n; i++)
	{
		printf("%2i", i);
		printf("%10s\t", Student[i].nume);
		printf("%5i\n", Student[i].NrMat);
	}

	printf("Introduceti nr matricol cautat in lista sortata dupa nr.matricol ^ : ");
	scanf("%i", &opt);

	for (i = 0; i < n; i++)
	{
		if ( opt == Student[i].NrMat )
		{
			printf("Persoana cu acest nr matricol se intalneste pe pozitia : ");
			printf("%i", i);
			break;
		}
	}
}

int main()
{
	int n;
	int i, j;
	Stud* Student;
	int ok;
	Stud aux;

	int opt;

	printf("Introduceti numarul de studenti : ");
	scanf("%i", &n);		// -citirea numărului de studenţi 

	Student = (Stud*)malloc(n * sizeof(Stud));

	for (i = 0; i < n; i++) //datele acestora;
	{
		printf("Introduceti Persoana %i : \n", i);
		printf("Nume : "); scanf("%s", Student[i].nume);
		printf("Numarul matricol : "); scanf("%i", &Student[i].NrMat);
	}

	system("cls");

	for (i = 0; i < n; i++) //  afişarea datelor tuturor studenţilor;
	{
		printf("%2i", i);
		printf("%10s\t", Student[i].nume);
		printf("%5i\n", Student[i].NrMat);
	}

	SortName(Student, n);
	printf("\n");
	SortNr(Student, n);

	return 0;
}
