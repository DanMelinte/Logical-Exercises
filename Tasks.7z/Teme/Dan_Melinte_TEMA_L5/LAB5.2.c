﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
/*
P6.// O matrice rară (contine 90% din elemente 0) este păstrată economic sub forma unei structuri, care conţine următoarele câmpuri:
	int l,c - numărul de linii/coloane al matricei rare;
	int n - numărul de elemente nenule
	int linii[] - vectorul ce păstrează liniile în care se află elemente nenule
	int coloane[] - vectorul ce păstrează coloanele în care se află elemente nenule
	float nenul[] - vectorul ce păstrează elementele nenule
Să se definească funcţii pentru:
 citirea unei matrice rare;
 afişarea unei matrice rare (ca o matrice, cu tot cu zerouri)
 adunarea a două matrice rare.
Observatii :
Vectorii linii[], coloane[], nenule[] vor avea fiecare cate n elemente.
Elementul nenul cu valoare nenule[index] se afla pe linia linii[index] si coloana coloane[index].
Elementele vor fi citite in ordinea crescatoare a liniilor, iar elementele de pe aceeasi linie in ordinea
crescatoare a coloanelor.
*/

/*
	Matricea rara este o matrice eficienta care stockeaza doar datele diferite de NULL (in cazul nostru 0) 
	pentru a economisi memorie, astfel matricea implementata in programul acesta pentru a putea fi patratica va 
	avea APROXIMATIV (cel putin) 90% din elementele sale elemtente nule si restul (cel mult) 10% elemente nenule dar depinde de numarul de valori nenule (n)
	introdus deoarece este necesara rotunjirea pentru a o face patratica => crste procentajul elementelor nule => scade procentajul celor nenule
*/

typedef struct
{
	int l, c;
	int n;
	int* linii;
	int* coloane;
	float* nenul;
}Matrix;

void AfisareaMatrciiRare(Matrix* Mat, int* nr)
{
	int i, j;
	int ok = 0;

	printf("\nMatricea nr %i : \n", *nr + 1);

	for (i = 0; i < Mat[*nr].l; i++)
	{
		for (j = 0; j < Mat[*nr].c; j++)
		{
			if (i == Mat[*nr].linii[ok] && j == Mat[*nr].coloane[ok])
			{
				printf("%3g", Mat[*nr].nenul[ok]);
				ok++;
			}
			else printf("%3i", 0);
		}
		printf("\n");
	}
}

void CitireaMatriciiRare(Matrix* Mat, int *nr)
{
	(*nr)++;

	int i, j;
	int ok = 0; // numarul de elemente nenule introduse

	if (*nr == 0)
	{
		printf("Introduceti n (numarul de elemente nenule) : ");
		scanf("%i", &Mat[*nr].n);
	}
	else Mat[*nr].n = Mat[0].n;

	if (!(Mat[*nr].nenul = (float*)malloc(Mat[*nr].n * sizeof(float))))
	{
		printf("Nu sa putut aloca memori"); 
		exit(0);		 // alocam memorie pentru elementele nenule 
	}													 // intre [10 - 0]% din nr total de elemente ale matricii
	/*
	marimea matricii rare :
	Mat[0].n - reprezinta 10% din elementele matricii si anume elementele nenule
	90% * n / 10% - reprezinta 90% din elementele matricii si anume elementele nule
	*/

	Mat[*nr].l = Mat[*nr].c = ceil(sqrt((Mat[*nr].n) + (90.0 * Mat[*nr].n) / 10.0)); // Initializam nr. de linii/coloane pentru matrice patractica deducand-o din nr de elemente nenule
	// ceil - rotunjeste succesiv

	Mat[*nr].linii = (int*)malloc(Mat[*nr].n * sizeof(int));
	Mat[*nr].coloane = (int*)malloc(Mat[*nr].n * sizeof(int)); // aloc memorie pentru cazul maxim cand fiecare element nenul va fi pe linie/coloana diferita

	printf("Matricea va avea marimea %ix%i\n", Mat[*nr].l, Mat[*nr].c);

	for (i = 0; i < Mat[*nr].l; i++)
	{
		for (j = 0; j < Mat[*nr].c; j++)
		{
			printf("Introduceti elementul [%i][%i] : ", i, j);
			scanf("%fl", &Mat[*nr].nenul[ok]);

			if (Mat[*nr].nenul[ok] != 0)
			{
				Mat[*nr].linii[ok] = i;
				Mat[*nr].coloane[ok] = j;
				ok++;
			}
			if (ok >= Mat[*nr].n)
				break;
		}
		if (ok >= Mat[*nr].n)
			break;
		if (ok < Mat[*nr].n && i + 1 >= Mat[*nr].l)
		{
			printf("\nNu ati introdus numarul de elementele NeNule => se completeaza spatiile libere cu 0");
			// Respectiv daca introducem un numar de elemente nenule (n) si nu introducem (n) elemente nenule in matrice 
			// acestea nu vor mai fi in proportii de 90% - 10% 
			// * In orice caz programul nu isi pierde sensul indeplinind logica de stocare a doar elementelor nenule (necesare)
			//	 Astfel mereu elementele nenule nu vor ocupa mai mult de 10% din matrice (defapt toate 100% elementele nule nefiind stocate)
		}
	}

	printf("In Matrice sunt %i - elemente NeNule ce reprezinta : %f%%", ok, (ok * 100.0) / (Mat[*nr].l * Mat[*nr].c));
	printf("\nIn Matrice sunt %i - elemente Nule ce reprezinta : %f%%", (Mat[*nr].l * Mat[*nr].c) - ok, (((Mat[*nr].l * Mat[*nr].c) - ok) * 100.0) / (Mat[*nr].l * Mat[*nr].c));
	AfisareaMatrciiRare(Mat, nr);
}

void AdunareaMatricilorRare(Matrix* Mat, int* nr)
{
	int i, j;
	float** Sum;
	int ok1 = 0; // pentru matricea nr 1
	int ok2 = 0; // pentru matricea nr 2

	for (i = 0; i < Mat[*nr].l; i++)
	{
		for (j = 0; j < Mat[*nr].c; j++)
		{
			if (i == Mat[*nr].linii[ok2] && j == Mat[*nr].coloane[ok2])
			{
				if (i == Mat[*nr - 1].linii[ok1] && j == Mat[*nr - 1].coloane[ok1])
				{
					printf("%3g", Mat[*nr].nenul[ok2] + Mat[*nr - 1].nenul[ok1]);
					ok2++;
					ok1++;
				}
				else
				{
					printf("%3g", Mat[*nr].nenul[ok2]);
					ok2++;
				}
			}
			else if (i == Mat[*nr - 1].linii[ok1] && j == Mat[*nr - 1].coloane[ok1])
			{
				printf("%3g", Mat[*nr - 1].nenul[ok1]);
				ok1++;
			}
			else printf("%3i", 0);
		}
		printf("\n");
	}
}

int main()
{
	int index;
	Matrix Mat[2]; // numarul de matrici
	int nr = -1;
	int i;
	char opt[20];

	while (nr < 1) //citim 2 matrici rare
	{
		CitireaMatriciiRare(Mat, &nr);
		printf("\n\n");
	}
	_getch();

	printf("\nSuma matricilor rare : \n");
	AdunareaMatricilorRare(Mat, &nr);

	return 0;
}