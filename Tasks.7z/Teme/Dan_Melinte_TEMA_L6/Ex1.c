﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
Aplicația 2.1: 
Pentru structura Vehicul de mai sus, să se implementeze funcțiile de introducere de la tastatură și
de afișare.
*/

typedef enum { TMBenzina, TMMotorina, TMElectric }TipMotor;
typedef enum { TVPersoane, TVMarfa, TVSpecial }TipVehicul;

typedef struct {
	TipMotor tm;
	char marca[20];
	TipVehicul tv;
	union {
		struct {
			unsigned int nrLocuri;
			unsigned int nrAirbaguri;
		}p;
		struct {
			double capacitate;
			unsigned char frigorific : 1; // false (0), true (1) Nu prea are sens ca totuna se completeaza in cazul dat pana la 1 octet dar pentru practica merge
		}m;
		char special[20]; // "tractor", "balastiera", ...
	}specific;
}Vehicul;

void introducere(Vehicul* V)
{
	int aux;
	printf("Introduceti Vehiculul : \n");
	printf("Marca : "); scanf("%s", V->marca);
	printf("Tip Vehicul (0-TVPersoane, 1-TVMarfa, 2-TVSpecial) : "); scanf("%i", &V->tv);
	switch (V->tv)
	{
	case TVPersoane:
		printf("Nr Locuri : "); scanf("%i", &V->specific.p.nrLocuri);
		printf("Nr Airbaguri : "); scanf("%i", &V->specific.p.nrAirbaguri);
		break;
	case TVMarfa:
		printf("Capacitate : "); scanf("%lf", &V->specific.m.capacitate);
		printf("Frigorific : "); scanf("%hhd", &aux); 
		V->specific.m.frigorific = aux;
		//inloc de %i
		break;
	case TVSpecial:
		printf("Special : "); scanf("%s", V->specific.special);
	default:
		break;
	}
	printf("Tip Motor (0-TMBenzina, 1-TMMotorina, 2-TMElectric) : "); scanf("%i", &V->tm);
}

void afisare(Vehicul V)
{
	printf("\n\nDatele Vehiculu-lui : \n");
	printf("Marca %s\n", V.marca);
	switch (V.tv)
	{
	case TVPersoane:
		printf("TipVehicul : TVPersoane\n");
		printf("Nr Locuri : %i\n", V.specific.p.nrLocuri);
		printf("Nr Airbaguri : %i\n", V.specific.p.nrAirbaguri);
		break;
	case TVMarfa:
		printf("TipVehicul : TVMarfa\n");
		printf("Capacitate : %f\n", V.specific.m.capacitate);
		printf("Frigorific : %hhd\n", V.specific.m.frigorific);
		break;
	case TVSpecial:
		printf("TipVehicul : TVSpecial\n");
		printf("Special : %s\n", V.specific.special);
		break;
	default:
		break;
	}

	switch (V.tm)
	{
	case TMBenzina:
		printf("Tip Motor : TMBenzina\n");
		break;
	case TMMotorina:
		printf("Tip Motor : TMMotorina\n");
		break;
	case TMElectric:
		printf("Tip Motor : TMElectric\n");
		break;
	default:
		break;
	}
}

int main()
{
	Vehicul V;
	introducere(&V);
	afisare(V);

	return 0;
}