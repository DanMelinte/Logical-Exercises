﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
/*
Aplicația 2.2: Folosind struct și union, definiți o structură de date care să poată memora următoarele informații despre viețuitoare:

 tipul (poate fi: mamifer, insectă, pește, pasăre)
 durata medie de viață în ani
 dacă e mamifer: perioada de gestație, numărul mediu de pui pe care îi naște
 dacă e insectă: numărul de picioare, dacă poate să zboare sau nu, dacă este periculoasă sau nu pentru om
 dacă e pește: tipul de apă: sărată/dulce, adâncimea maximă la care se poate întâlni, viteza maximă de înot
 dacă e pasăre: anvergura aripilor, altitudinea maximă de zbor, viteza maximă de zbor

Definiți structura în așa fel încât memoria consumată să fie minimă. 
Citiți și afișați informațiile despre o viețuitoare.
*/

typedef enum { Mamifer, Insecta, Peste, Pasare }Tip;
typedef enum { Dulce, Sarata }TipApa;

typedef struct
{
	unsigned char TP: 3;  //Tipul
	unsigned int DurataMedViata; //Durata medie de viata sunt anumite insecte sau moluste care pot trai un timp neidentificat => nu depun limite

	union {
		struct
		{
			unsigned int PerioadaGestatie : 10; // precum este foarte variata (Elefant ~600 zile ~ 20 luni) rezervez 10 biti 
			unsigned int NumarulMDePui : 12; // (paianjen ~3000 oua)
		}ma;
		struct
		{
			unsigned int NrPicioare : 11; // prea variat (miriapod ~1300 picioare) 11 biti
			unsigned char Aeriana : 1;       // %hhd sau putem folosi bool importand biblioteca stdbool.h
			unsigned char PericolPtOm : 1; 	// %hhd	sau putem folosi bool importand biblioteca stdbool.h
			//Observatie : char : 1 => de la -1 la 0 
			   // unsigned char : 1 => de la  0 la 1
		}in;
		struct
		{
			unsigned char Apa : 1; //0-Sarata, 1-Dulce
			unsigned int AdancimeaMax : 14; //cel mai adanc punct din oceanul planetar ~10994 metri = 14 biti
			unsigned int VitezaMaxInot : 7; // peşte Barcă cu pânze ~ 112 km/h = 7 biti
		}pe;
		struct
		{
			unsigned int AnverguraAripi : 8; //8 biti = 255 cu rezerva
			unsigned int AltitudineaMaxZbor : 7; // atmosfera se intinde pana 100km logic🙃
			unsigned int VitezaMaxZbor : 8; //Șoim călător ~ 242km/h
		}pa;
	}TipDetail;
}Vietuitoare;

void introducere(Vietuitoare* A)
{
	int aux;
	printf("Introduceti Datele :\n");

	printf("Tipul (0-Mamifer, 1-Insecta, 2-Peste, 3-Pasare) : "); scanf("%hhd", &aux); A->TP = aux;
	switch (A->TP)
	{
	case Mamifer: 
		printf("Perdioada de Gestatie : "); scanf("%i", &aux);
		A->TipDetail.ma.PerioadaGestatie = aux;
		printf("Numarul De Pui : "); scanf("%i", &aux);
		A->TipDetail.ma.NumarulMDePui = aux;
		break;
	case Insecta: 
		printf("Nr de Picioare : "); scanf("%i", &aux);
		A->TipDetail.in.NrPicioare = aux;
		printf("Poate zbura (0-nu, 1-da) : "); scanf("%hhd", &aux);
		A->TipDetail.in.Aeriana = aux;
		printf("Pericol pentru Om (0-nu, 1-da) : "); scanf("%hhd", &aux);
		A->TipDetail.in.PericolPtOm = aux;	
		break;
	case Peste: 
		printf("Adancimea maxima la care se intalneste : "); scanf("%i", &aux);
		A->TipDetail.pe.AdancimeaMax = aux;
		printf("Tipul de apa (0-Dulce, 1-Sarata) : "); scanf("%hhd", &aux); A->TipDetail.pe.Apa = aux;
		printf("Viteza Maxima de inot : "); scanf("%i", &aux);
		A->TipDetail.pe.VitezaMaxInot = aux;
		break;
	case Pasare:
		printf("Altitudinea maxima de zbor : "); scanf("%i", &aux);
		A->TipDetail.pa.AltitudineaMaxZbor = aux;
		printf("Anvergura Aripilor : "); scanf("%i", &aux);
		A->TipDetail.pa.AnverguraAripi = aux;
		printf("Viteza Maxima de zbor : "); scanf("%i", &aux);
		A->TipDetail.pa.VitezaMaxZbor = aux;
		break;
	default:
		printf("Eroare - Tipul");
		break;
	}
	printf("Durata Medie de viata : "); scanf("%i", &A->DurataMedViata);
}

void afisare(Vietuitoare* A)
{
	printf("\n\nDatele :\n");
	switch (A->TP)
	{
	case Mamifer:
		printf("Tipul : Mamifer");
		printf("\nPerdioada de Gestatie : %i", A->TipDetail.ma.PerioadaGestatie);
		printf("\nNumarul De Pui : %i", A->TipDetail.ma.NumarulMDePui);
		break;
	case Insecta:
		printf("Tipul : Insecta");
		printf("\nNr de Picioare : %i", A->TipDetail.in.NrPicioare);
		printf("\nPoate zbura : %hhd", A->TipDetail.in.Aeriana);
		printf("\nPericol pentru Om : %hhd", A->TipDetail.in.PericolPtOm);
		break;
	case Peste:
		printf("Tipul : Peste");
		printf("\nAdancimea maxima la care se intalneste : %i", A->TipDetail.pe.AdancimeaMax);
		switch (A->TipDetail.pe.Apa)
		{
		case Dulce:
			printf("\nTipul de Apa : Dulce");
			break;
		case Sarata:
			printf("\nTipul de Apa : Sarata");
			break;
		default:
			printf("\nEroare-Tip");
			break;
		}
		printf("\nViteza Maxima de inot : %i", A->TipDetail.pe.VitezaMaxInot);
		break;
	case Pasare:
		printf("Tipul : Pasare");
		printf("\nAltitudinea maxima de zbor : %i", A->TipDetail.pa.AltitudineaMaxZbor);
		printf("\nAnvergura Aripilor : %i", A->TipDetail.pa.AnverguraAripi);
		printf("\nViteza Maxima de zbor : %i", A->TipDetail.pa.VitezaMaxZbor);
		break;
	default:
		printf("\nEroare - Tipul");
		break;
	}
	printf("\nDurata Medie de viata : %i", A->DurataMedViata);
}

int main()
{
	Vietuitoare A;
	introducere(&A);
	afisare(&A);

	return 0;
}