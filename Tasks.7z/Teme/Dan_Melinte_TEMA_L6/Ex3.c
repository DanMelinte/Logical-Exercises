﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <string.h>
/*
Aplicația 2.3: Se citește de la tastatură o linie de text care conține o atribuire a unei variabile cu o valoare. 
Linia are forma ”nume_variabila=valoare”. 
Numele variabilei poate conține doar litere sau cifre, cu restricția ca primul caracter să fie literă. 
Valoarea poate fi număr (începe cu o cifră și poate avea zecimale), caracter (începe cu apostrof) sau șir de caractere (începe cu ghilimele). 

Câteva exemple de astfel de atribuiri:
raza=10.12
B22 = 'c'
adresa="Bd. Vasile Parvan nr. 2"

Folosind struct și union definiți o structură de date pentru a păstra în mod eficient informația din linia citită de la
tastatură. Transferați informația din linia citită într-o variabilă de tipul structurii de date definite. Afișați informația
păstrată în variabilă, folosind formatul original (nume_variabila=valoare). Tratați posibile erori ce pot să apară în
linia citită (nume incorect de variabilă, lipsește semnul egal, valoarea atribuită este invalidă).
*/

typedef struct
{
	char* NumeVariabila; // faptul ca nu aloc informatia decat atat cat este necesar folosind alocarea dinamica este destul de eficient
	char* Valoarea;  // faptul ca nu aloc informatia decat atat cat este necesar folosind alocarea dinamica este destul de eficient
}Atribuire;

void introducere(Atribuire* A)
{
	char LinieText[50]; // rezervez cu rezerva 
	int n;
	int i, j;

	int NrNume = 0;
	int NrVal = 0;
	int ok = 1;

	printf("Introduceti Linia de text sub forma \"nume_variabila=valoare\" : \n");
	scanf("%s", LinieText);
	n = strlen(LinieText);

	if (LinieText[0] >= '0' && LinieText[0] <= '9') //verificam ca numele variabilei sa nu se inceapa cu o cifra
		ok = 0;

	if (ok)
	{
		ok = 0;
		for (i = 0; i < n; i++)
		{
			if (LinieText[i] != '=')
				NrNume++; // numarul de caractere folosesc la alocarea dinamica 
			else
			{
				NrVal = n - NrNume - 1; //numarul de caractere folosesc la alocarea dinamica (-1) : pentru ca scadem si caracterul '='
				ok = 1;
				break;
			}
		}

		if (ok == 0)
			printf("Eroare - Lipseste semnul =");
		else {
			A->NumeVariabila = (char*)malloc(NrNume * sizeof(char));
			strcpy(A->NumeVariabila, LinieText);
			A->NumeVariabila[NrNume] = '\0';

			A->Valoarea = (char*)malloc(NrVal * sizeof(char));
			strncpy(A->Valoarea, LinieText + NrNume + 1, NrVal + 1);
			A->Valoarea[NrVal] = '\0';


			if ((A->Valoarea[0] >= '0' && A->Valoarea[0] <= '9')) //daca este cifra este exclus alte caractere inafara de cifa si punct
			{
				for (i = 1; i < NrVal; i++)
				{
					if ((A->Valoarea[i] < '0' || A->Valoarea[i] > '9') && A->Valoarea[i] != '.')
					{
						ok = 0;
						break;
					}
				}
				if (!ok)
					printf("Eroare - Valoare nevalida - Ati incercat sa introduceti un caracter in numar");
			}
			else if (A->Valoarea[0] == '\'') //daca este caracter trebuie apostrof la inceput si sfarsit si lungimea sa fie 3
			{
				if (A->Valoarea[NrVal - 1] != '\'' || NrVal != 3)
					ok = 0;
				if (!ok)
					printf("Eroare - Valoare nevalida - Caracterul trebuie sa inceapa si termine cu apostrof si sa fie un singur caracter");
			}
			else if (A->Valoarea[0] == '\"') //daca este caracter trebuie apostrof la inceput si sfarsit si lungimea sa fie 3
			{
				if (A->Valoarea[NrVal - 1] != '\"')
					ok = 0;
				if (!ok)
					printf("Eroare - Valoare nevalida - Sirul de caractere trebuie sa se inceapa si termine cu gilimele");
			}

			if (ok)
				printf("%s=%s", A->NumeVariabila, A->Valoarea);
		}
	}
	else printf("Eroare - Nume incorect variabila");
}

int main()
{
	Atribuire A;
	introducere(&A);

	return 0;
}