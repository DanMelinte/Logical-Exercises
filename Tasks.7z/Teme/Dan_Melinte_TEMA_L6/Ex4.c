﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <string.h>
/*
Aplicația 2.4: Folosind câmpuri pe biți, definiţi o structură pentru memorarea următoarelor informaţii despre animale:

 numărul de picioare: număr întreg, minim 0 (ex. şarpe), maxim 1000 (ex. miriapod)
 greutatea în kg: număr real
 periculos pentru om: da/nu
 abrevierea ştiinţifică a speciei: şir de maxim 8 caractere
 vârsta maximă în ani: număr întreg, minim 0, maxim 2000

Unde este posibil, codificaţi informaţiile prin numere întregi de dimensiune cât mai mică, spre exemplu “da”=1,
“nu”=0. Definiţi structura în aşa fel încât să ocupe spaţiul minim de memorie posibil. Afişaţi spaţiul de memorie
ocupat, folosind operatorul sizeof. Folosind structura definită, citiţi de la tastatură informaţii despre un animal, iar
pe urmă afişaţi-le pe ecran.

*/

typedef struct Anim
{
	unsigned int VarstaMax : 11; //11 biti in loc 4 octeti = 32 biti
	unsigned int NumarPicioare : 10; //maxim 1000 maxim 7 biti 
	unsigned int Pericol : 1; // putem utiliza chiar un bit numai pentru 0-nu, 1-da in loc la un octet = 8 biti

	char Abreviere[8]; // char *Abreviere; - pentru si mai mare eficenta de memorie
	float Greutatea;
}Animal;

void introducere(Animal* A)
{
	int aux;
	int i = 0;

	printf("Introduceti Animalul : \n");
	printf("Numarul de picioare : "); scanf("%i", &aux); A->NumarPicioare = aux;
	printf("Greutatea : "); scanf("%f", &A->Greutatea);
	printf("Pericol pentru om (0-nu, 1-da) : "); scanf("%hhd", &aux); A->Pericol = aux;
	printf("Abrevierea Stiintifica : "); scanf("%s", A->Abreviere);
	printf("Varsta maxima (ani) : "); scanf("%i", &aux); A->VarstaMax = aux;

	printf("%i - octeti", sizeof(struct Anim));
}

void Afisare(Animal* A)
{
	printf("\n\nDatele despre animal : \n");

	printf("%i\n", A->NumarPicioare);
	printf("%g\n", A->Greutatea);
	printf("%i\n", A->Pericol);
	printf("%s\n", A->Abreviere);
	printf("%i\n", A->VarstaMax);
}

int main()
{
	Animal A;
	introducere(&A);
	Afisare(&A);

	return 0;
}