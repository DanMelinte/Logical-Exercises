﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
/*
Aplicația 2.5: Se consideră că o măsurătoare are asociată unitatea de măsură (gram, metru, litru) și
multiplicatorul acesteia (pico, nano, mili, centi, deci, deca, hecto, kilo, mega, giga).

 Să se codifice o măsurătoare astfel încât să conțină o valoare întreagă pozitivă care să acopere un
interval cât mai mare de valori, unitatea de măsură și multiplicatorul acesteia. O măsurătoare va ocupa
exact 2 octeți.

 Să se citească o valoare unsigned și o unitate de măsură. La citire nu există multiplicator. Să se
determine multiplicatorul astfel încât valoarea stocată să fie cât mai mică, fără a se pierde precizie, iar
apoi să se stocheze într-o măsurătoare. Dacă valoarea nu încape, se va afișa o eroare. Să se afișeze
toate câmpurile măsurătorii.

Exemplu: valoare=147000, unitate:gram => 147 kilogram
*/

typedef enum { pico, nano, mili, centi, deci, deca, hecto, kilo, mega, giga}Mltpl;
typedef enum {gram, metru, litru}Unitate;

struct Masurator
{
	unsigned short int Unitate : 2; // <= 3
	unsigned short int Multiplicator : 4; // <= 10
	unsigned short int Valoare : 10; //[0, 1023]
};

// Nu prea am inteles partea cu multiplicatorul adica pentru ce este necesar sal introducem daca programul ar trebui automat sa gasesca 
// cea mai optima reprezentare a numarului 

void introducere(struct Masurator* M)
{
	int aux;
	unsigned int a;
	unsigned int b;
	int i = 0;

	char Unit[6]; //pentru frumusete la introducere inloc de 0 1 2 <=> gram metru litru

	printf("%i octeti\n", sizeof(struct Masurator));

	printf("Introduceti o valoare : "); 
	do {
		scanf("%i", &a);
	} while (a <= 0);
	b = a;

	printf("Introduceti o unitate de masura (gram, metru, litru) : "); 
	scanf("%s", Unit);

	if (!strcmp(Unit, "gram"))
		M->Unitate = gram;  //0
	else if (!strcmp(Unit, "metru"))
		M->Unitate = metru; //1
	else if (!strcmp(Unit, "litru"))
		M->Unitate = litru; //2

	while (b % 10 == 0) { //Numaram zerourile de la final
		b /= 10;
		i++;
	}

	if (i == 1) {
		a /= 10;
		printf("%i ", a);
		M->Multiplicator = deca;
		printf("deca");
	}
	else if (i == 2) {
		a /= pow(10, 2);
		printf("%i ", a);
		M->Multiplicator = hecto;
		printf("hecto");
	}
	else if (i >= 3 && i < 6)
	{
		a /= pow(10, 3);
		printf("%i ", a);
		M->Multiplicator = kilo;
		printf("kilo");
	}
	else if (i >= 6 && i < 9) {
		a /= pow(10, 6);
		printf("%i ", a);
		M->Multiplicator = mega;
		printf("mega");
	}
	else if (i >= 9) {
		a /= pow(10, 9);
		printf("%i ", a);
		M->Multiplicator = giga;
		printf("giga");
	}
	else printf("%i ", a);

	switch (M->Unitate)
	{
	case gram: 
		printf("gram");
		break;
	case metru: 
		printf("metru"); 
		break;
	case litru: 
		printf("litru"); 
		break;
	default:
		break;
	}

	if (a > 1023)
		printf("\nNu incape in structura");
	else
	{
		aux = a;
		M->Valoare = a;
	}
}
void afisare(struct Masurator * M)
{
	printf("\n\nUnitatea : %i", M->Unitate);
	switch (M->Unitate)
	{
	case gram: printf(" (gram)"); break;
	case metru: printf(" (metru)"); break;
	case litru: printf(" (litru)"); break;
	default:
		break;
	}

	printf("\nMultiplicatorul : %i (", M->Multiplicator);
	switch (M->Multiplicator)
	{
	case pico: printf("pico"); break;
	case nano: printf("nano"); break;
	case mili: printf("mili"); break;
	case centi:printf("centi"); break;
	case deci: printf("deci"); break;
	case deca: printf("deca"); break;
	case hecto:printf("hecto"); break;
	case kilo: printf("kilo"); break;
	case mega: printf("mega"); break;
	case giga: printf("giga"); break;
	default:
		break;
	}

	printf(")\nValoare : %i", M->Valoare);
}
int main()
{
	struct Masurator M;
	introducere(&M);
	afisare(&M);
	return 0;
}