﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <string.h>
/*
Aplicația 2.6: Să se codifice următoarele informații despre un medicament, astfel încât ele să ocupe în total un
singur octet. Să se scrie un program care să citească datele unui medicament și ulterior să le afișeze.
 gradul de periculozitate: scăzută, medie, mare
 dacă se eliberează doar pe bază de rețetă: da, nu
 vârsta minimă de administrare: 1...18 ani inclusiv
*/

struct medicament
{
	unsigned char GradPericulozitate : 2;
	unsigned char EliberareaPeBazaReteta : 1;
	unsigned char VarstaMinima : 5;
};

void introducere(struct medicament* M)
{
	int aux;

	printf("%i octeti\n", sizeof(struct medicament));

	printf("Gradul de periculozitate (0-scazuta, 1-medie, 2-mare) : "); scanf("%hhd", &aux); M->GradPericulozitate = aux;
	printf("Se elibereaza pe baza de reteta (0-nu, 1-da) : "); scanf("%hhd", &aux); M->EliberareaPeBazaReteta = aux;
	printf("Varsta minima de administrare [1-18] : "); scanf("%hhd", &aux); M->VarstaMinima = aux;
}

void afisare(struct medicament* M)
{
	printf("\n%hhd", M->GradPericulozitate);
	printf("\n%hhd", M->EliberareaPeBazaReteta);
	printf("\n%hhd", M->VarstaMinima);
}

int main()
{
	struct medicament M;
	introducere(&M);
	afisare(&M);

	return 0;
}