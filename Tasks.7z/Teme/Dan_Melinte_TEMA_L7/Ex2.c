﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/*
Problema 7.7. Scrieţi un program care citeşte de la tastatură un număr N, apoi citeşte N numere întregi, iar la
final afişează cele N numere în ordine inversă. Programul va folosi alocarea dinamică pentru memorarea celor
N numere.
*/

int main()
{
	int N;
	int i, j;

	int* Numere;

	int* aux;

	printf("Introduceti un numar : "); scanf("%i", &N);

	Numere = (int*)malloc(N * sizeof(int));
	aux = (int*)malloc(N * sizeof(int));

	for (i = 0; i < N; i++)
	{
		printf("Nr[%i] : ", i);
		scanf("%i", Numere + i); // <=> &Numere[i]
	}

	for (i = 0; i < N; i++)
		printf("\n%i", *(Numere + i));

	printf("\n\nOrdine inversa :");

	for (i = N - 1, j = 0; i >= 0; i--, j++)
	{
		aux[j] = Numere[i];
	}

	for (i = 0; i < N; i++)
		printf("\n%i", *(aux + i));

	free(Numere);
	free(aux);

	return 0;
}