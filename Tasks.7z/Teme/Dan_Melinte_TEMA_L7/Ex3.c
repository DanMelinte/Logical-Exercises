﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>

/*
Problema 7.8. Aceeaşi problemă ca mai sus, cu diferenţa că nu se ştie de la început câte numere vor fi introduse.
Programul va începe direct cu citirea numerelor, fără a-l citi pe N. Citirea se va încheia în momentul în
care se introduce numărul 0. Programul va folosi alocarea dinamică astfel încât spaţiul de memorie consumat
să fie minim.
*/

int main()
{
	int i, j;

	int* Numere = NULL;
	int* auxx;
	int Nr;
	int N = 0;

	int *aux;

	do
	{
		printf("Nr[%i] : ", N);
		scanf("%i", &Nr); // Citim un numar

		N++;
	
		auxx = (int*)realloc(Numere, N * sizeof(int));
		Numere = auxx; // asociem adresa lui Numere la adresa lui auxx

		*(Numere + N - 1) = Nr; // stocam in Numere pe adresa pozitia N-1 numarul introdus
	} while (Nr != 0);

	for (i = 0; i < N; i++)
		printf("\n%i", Numere[i]);

	aux = (int*)malloc(N * sizeof(int));

	printf("\n\nOrdine inversa :");
	for (i = N - 1, j = 0; i >= 0; i--, j++)
	{
		aux[j] = Numere[i];
	}


	for (i = 0; i < N; i++)
		printf("\n%i", *(aux + i));

	free(Numere);
	free(aux);

	return 0;
}