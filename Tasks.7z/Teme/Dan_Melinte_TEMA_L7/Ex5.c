﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
/*
Problema 7.10. Scrieţi un program care estimează capacitatea zonei de memorie dinamică alocând în mod repetat
blocuri de memorie până când nu mai există memorie disponibilă (funcţia malloc returnează NULL). 

La alocare folosiţi dimensiuni de ordinul KB (spre exemplu 10240 bytes). (Atenţie: în timpul rulării programului puteţi experimenta scăderi
de performanţă în sistemul de operare) Număraţi câte blocuri sunt alocate cu succes, iar în momentul în care nu mai
există memorie disponibilă afişaţi totalul de memorie alocat, după care încheiaţi execuţia programului. Pentru această
problemă nu e nevoie să eliberaţi memoria alocată.
*/

int OneGB = 1048576; // un gb in kb

// Sistema mea de operare permite absoluta alocare a memoriei astfel windowsul opreste procesele sistemei 
// si ofera spatiu programului pana da crash(cateodata VS mai repede face crash cateodata windowsul)

// Astfel am pus o conditie de oprire cand ajung la o anumita limita

int main()
{
	int* a;
	float n = 0;

	while ((a = (int*)malloc(1024)) != NULL)
	{
		n++; // numarul de blocuri alocate cu success
		if (n >= OneGB * 1.5) // 1.5 gb
			break;
	}

	printf("%f GB | ", n / OneGB);
	printf("%.0f KB | ", n); // numarul de blocuri alocate cu success
	printf("%.0f Bytes \n", n * 1024);
	printf("\nMarimea la bloc = KB");

	_getch();
	return 0;
}