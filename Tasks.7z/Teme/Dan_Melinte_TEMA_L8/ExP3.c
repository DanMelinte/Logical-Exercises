#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>

/*
P3: Intr-un fisier pe fiecare linie se afla cate 2 numere reale separate prin spatiu care sunt coordonatele unui punct in
plan. Se cere sa se afiseze coordonatele punctului care este cel mai apropiat de originea axelor.
*/

void CitireFisier(FILE* fisier, float *n)
{
	int i;
	float x, y; // le vom folosi ca variabile temporare iar in una din ele vom stoca si rezultatul final pentru economisirea spatiului
	int nr = 0;

	float* aux;

	if ((fisier = fopen("aaa.txt", "r")) == NULL)
	{
		printf("Eroare - Creareare Fisier");
		exit(0);
	}

	n = (int*)malloc(1);

	while (!feof(fisier))
	{
		if ((fscanf(fisier, "%f %f", &x, &y)) != 0) // Daca citirea din fisier a fost cu success
		{
			nr++;
			aux = (int*)realloc(n, nr * sizeof(char*));
			n = aux;
			n[nr] = sqrt((x * x) + (y * y));
			printf("%g\n", n[nr]);
		}
	}

	x = n[1]; // vom stoca in x rezultatul final

	for (i = 2; i < nr; i++)
		if (x > n[i])
			x = n[i];

	printf("Cea mai mica distanta - %g", x);

	free(n);
	fclose(fisier);
}

int main()
{
	float* n; // tabloul cu distantele fiecarui punct

	FILE* fisier;

	CitireFisier(&fisier, &n);

	return 0;
}