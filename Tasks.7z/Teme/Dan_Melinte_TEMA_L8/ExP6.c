#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/*
P6. In fisierul �in.txt� pe fiecare linie este cate un numar real ce semnifica salariul unei persoane. 
Se cere sa se citeasca toate aceste numere si cele care sunt mai mici decat 1000 sa se indexeze cu 15%. 
Toate numerele rezultate (si cele ramase identice) se vor scrie in fisierul �indexate.txt�, cate unul pe linie.
*/

void CitireFisier(FILE* fisierIN, FILE* fisierOUT)
{
	float a;

	if ((fisierIN = fopen("in.txt", "r")) == NULL)
	{
		printf("Eroare - Creare Fisier");
		exit(0);
	}

	if ((fisierOUT = fopen("indexate.txt", "w")) == NULL)
	{
		printf("Eroare - Creare Fisier");
		exit(0);
	}

	while (!feof(fisierIN))
	{
		if ((fscanf(fisierIN, "%f", &a) != NULL))
		{
			printf("%10g -> ", a);
			if (a < 1000)
				a += 15 * a / 100;

			printf("%g\n", a);

			fprintf(fisierOUT, "%g\n", a);
		}
		else
		{
			printf("Nu reprezinta un numar\n"); 
			exit(0);
		}
	}

	fclose(fisierIN);
	fclose(fisierOUT);
}

int main()
{
	FILE* fisierIN;
	FILE* fisierOUT;

	CitireFisier(&fisierIN, &fisierOUT);

	return 0;
}