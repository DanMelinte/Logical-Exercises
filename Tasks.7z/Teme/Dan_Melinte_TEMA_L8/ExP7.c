#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/*
P7. Se cere numele unui fisier. 
Sa se contorizeze de cate ori apare in el fiecare litera 
si sa se afiseze literele aparute si numarul lor de aparitii.
*/

typedef struct
{
	char Litera;
	int NrAparitii;
}Lit;

void CitireFisier(FILE* fisierIN)
{
	Lit* Litere;
	Lit* tempLIT;

	char ch;
	int n = 0; // Numarul de litere;

	int ok;

	int i;

	if ((fisierIN = fopen("in.txt", "r")) == NULL)
	{
		printf("Eroare - Creare Fisier");
		exit(0);
	}

	Litere = (Lit*)malloc(sizeof(Lit*)); // pentru o litera si o cifra

	while (!feof(fisierIN))
	{
		ch = fgetc(fisierIN);

		if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
		{
			ok = 0;
			for (i = 0; i < n; i++)
			{
				if (ch == Litere[i].Litera)
				{
					Litere[i].NrAparitii++;
					ok = 1;
				}
			}

			if (ok == 0)
			{
				Litere[n].Litera = ch;
				Litere[n].NrAparitii = 1; // litera in exemplar unic (apare doar odata)
				n++;
				if (!(tempLIT = (Lit*)realloc(Litere, (n + 1) * sizeof(Lit*))))
				{
					printf("\nEroare - Alocare Memorie");
					exit(0);
				}
				Litere = tempLIT;
			}
		}
	}

	for (i = 0; i < n; i++)
		printf("%c - %i aparitii\n", Litere[i].Litera, Litere[i].NrAparitii);

	fclose(fisierIN);
}

int main()
{
	FILE* fisierIN;

	CitireFisier(&fisierIN);

	return 0;
}