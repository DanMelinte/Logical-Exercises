#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/*
P8. Un fisier are cate o propozitie pe fiecare linie. 
Se cere sa se scrie intr-un fisier destinatie fiecare propozitie tot pe
cate o linie dar pusa intre ghilimele.
*/

void CitireFisier(FILE* fisierIN, FILE* fisierOUT)
{
	char ch;
	char* chs; // un rand
	char* tempChs; // un rand

	int n = 0; // nr de caractere in fiecare rand

	if ((fisierIN = fopen("in.txt", "r")) == NULL)
	{
		printf("Eroare - Deschidere Fisier");
		exit(0);
	}

	if ((fisierOUT = fopen("out.txt", "w")) == NULL)
	{
		printf("Eroare - Creare Fisier");
		exit(0);
	}

	chs = (char*)malloc(sizeof(char));

	while (!feof(fisierIN))
	{
		if ((ch = fgetc(fisierIN))) // deasemenea se poate folosi si fgets
		{
			if (ch != '\n' && ch != EOF)
			{
				tempChs = (char*)realloc(chs, (n + 2) * sizeof(char*)); // pentru litera curenta + litera urmatoare si +1 pentru terminator de sir
				chs = tempChs;
				chs[n] = ch;
				chs[n + 1] = '\0';
				n++;
			}
			else
			{
				fprintf(fisierOUT, "\"%s\"\n", chs);
				n = 0;
				chs = (char*)malloc(sizeof(char));
			}
		}
	}

	free(chs);
	fclose(fisierIN);
	fclose(fisierOUT);
}

int main()
{
	FILE* fisierIN;
	FILE* fisierOUT;

	CitireFisier(&fisierIN, &fisierOUT);

	return 0;
}