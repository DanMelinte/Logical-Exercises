﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>

/*
1.6. Se citesc 2 valori naturale nr. şi bit (0 <= bit <= 15). Să se marcheze cu 1 bitul bit al lui nr.
Indicatie: setati valoarea 1 la bitul bit, indiferent de valoarea memorată anterior (0 sau 1).
Pentru setare, utilizati operatorul sau pe biţi.
Expresia care realizează aceasta este nr | (1 << bit) .
Observatie Am vazut anterior că 1 <<b înseamnă 2
b
Expresia nr | 2bit nu va modifica decât bitul bit care ne interesează, restul rămânând nemodificaţi,
datorită faptului că dacă b este un bit atunci b | 0 este egal cu b.
*/

void Show(int nr)
{
	int i;
	for (i = 16; i >= 0; i--)
		printf("%i", (nr >> i) & 1);
}

int main() {
	int nr;
	int bit;
	int i;

	printf("Dati nr : ");
	scanf("%d", &nr);

	printf("Dati bitul : ");
	scanf("%d", &bit);

	Show(nr);

	nr = nr | (1 << bit);
	nr = (nr >> bit) | 1;

	printf("\n");

	Show(nr);

	return 0;
}