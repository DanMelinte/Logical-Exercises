﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>

/*
1.7. Se consideră două numere naturale nr1 şi nr2, ambele cuprinse între 0 şi 255. Se cere să se
memoreze cele două numere într-un întreg nr reprezentabil pe 16 biţi fără semn (deci de tip unsigned
short).
Indicatie: Cele două numere nr1 şi nr2 pot fi reprezentate pe 8 biţi. De aceea cei 16 biţi ai lui nr sunt
suficienţi. Stocăm nr1 pe primii 8 biţi ai lui nr, iar pe nr2 pe ultimii 8 biţi ai lui nr.
nr = nr1 * 256 + nr2 ;
De asemenea, dacă se cunoaşte nr, se pot obţine valorile lui nr1 şi nr2 astfel:
nr1 = nr >> 8 ; // sau nr1 = nr / 256 ;
nr2= nr & 255 ; // sau nr2 = nr % 256 ;
*/

void Show(int nr1, int nr2)
{
	int i;
	for (i = 7; i >= 0; i--)
		printf("%i", (nr1 >> i) & 1);

	printf("\n");

	for (i = 7; i >= 0; i--)
		printf("%i", (nr2 >> i) & 1);

	printf("\n");
}

int main() {
	int nr1, nr2;
	unsigned short nr;

	int i;

	do
	{
		printf("Dati nr1 : ");
		scanf("%d", &nr1);

		printf("Dati nr2 : ");
		scanf("%d", &nr2);
	} while (nr1 > 255 || nr1 < 0 || nr2 > 255 || nr2 < 0);

	Show(nr1, nr2);

	nr = nr1 * 256 + nr2; // stocam nr1 pe ultimii cei mai semnificativi 8 biti a lui nr inmultind cu 256 
						  // Iar pe primii 8 biti stocam nr2

	printf("\nnr = %d\n", nr);

	for (i = 15; i >= 8; i--)
		printf("%i", (nr >> i) & 1);
	printf(" ");
	for (i = 7; i >= 0; i--)
		printf("%i", (nr >> i) & 1);

	printf("\nExtras din nr - nr1 = %i", nr >> 8); // nr1
	printf("\nExtras din nr - nr2 = %i", nr & 255);// nr2

	return 0;
}